/* 선택 페이지 */
let choice_page1_container = document.querySelector(".choice_page1_container");
let choice_page2_container = document.querySelector(".choice_page2_container");
let choice = document.querySelectorAll(".choice");
let vision = document.querySelector(".vision");
let main_container = document.querySelector(".main_container");

/* next, prev btn */
function next_prev_btn(){
    let next_btn = document.querySelector(".next_btn");
    let prev_btn = document.querySelector(".prev_btn");
    next_btn.addEventListener("touchstart", () => {
        next_btn.src = "image/next_out.png";
    });
    next_btn.addEventListener("touchend", () => {
        next_btn.src = "image/next.png";
    });
    prev_btn.addEventListener("touchstart", () => {
        prev_btn.src = "image/prev_out.png";
    });
    prev_btn.addEventListener("touchend", () => {
        prev_btn.src = "image/prev.png";
    });
}
next_prev_btn();
/* BGM */
let BGM =document.querySelector("audio");
BGM.volume = 0.2;

/*선택 시 */
for(let i = 0; i < choice.length; i++){
    choice[i].addEventListener("click", ()=>{
        choice_page1_container.style.display = "none";
        choice_page2_container.style.display = "none";
        main_container.classList.add("hover");
        main_container.style.animation = "Opacity .5s";
    });
}

let eyes_img = document.querySelector('.eyes_img');
let nose_img = document.querySelector('.nose_img');
let mouse_img = document.querySelector('.mouse_img');
let ex_img = document.querySelector('.ex_img');
let eyesImg_1 = document.querySelector(".eyesImg_1");
let noseImg_1 = document.querySelector(".noseImg_1");
let mouseImg_1 = document.querySelector(".mouseImg_1");
let eyesImg_2 = document.querySelector(".eyesImg_2");
let noseImg_2 = document.querySelector(".noseImg_2");
let mouseImg_2 = document.querySelector(".mouseImg_2");
let eyesImg_3 = document.querySelector(".eyesImg_3");
let noseImg_3 = document.querySelector(".noseImg_3");
let mouseImg_3 = document.querySelector(".mouseImg_3");
let eyesImg_4 = document.querySelector(".eyesImg_4");
let noseImg_4 = document.querySelector(".noseImg_4");
let mouseImg_4 = document.querySelector(".mouseImg_4");
let eyes_container = document.querySelector(".eyes_container");
let nose_container = document.querySelector(".nose_container");
let mouse_container = document.querySelector(".mouse_container");


/* 머리,몸통 */
var face_container = document.querySelector(".face_container");
var body_img = document.querySelector(".body_img");
var face_img = document.querySelector(".face_img");
/* 남자 얼굴 */
function boy(){
    choice[0].addEventListener("click",()=>{//사랑
        eyes_img.src = "image/눈0.png";
        nose_img.src = "image/코0.png";
        mouse_img.src = "image/입0.png";
        ex_img.src = "image/boy/완성이미지_1.png";
        document.body.style.backgroundImage ="url(image/배경1.png)";
        
    });
    choice[1].addEventListener("click",()=>{//졸음
        eyes_img.src = "image/눈1.png";
        nose_img.src = "image/코1.png";
        mouse_img.src = "image/입1.png";
        ex_img.src = "image/boy/완성이미지_2.png";
        document.body.style.backgroundImage ="url(image/배경1.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
    
        eyesImg_4.setAttribute('data-ok',true);
        noseImg_4.setAttribute('data-ok',true);
        mouseImg_4.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_1");
        nose_container.classList.add("hover_1");
        mouse_container.classList.add("hover_1");
    });
    choice[2].addEventListener("click",()=>{//화남
        eyes_img.src = "image/눈2.png";
        nose_img.src = "image/코2.png";
        mouse_img.src = "image/입2.png";
        ex_img.src = "image/boy/완성이미지_3.png";
        document.body.style.backgroundImage ="url(image/배경1.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
    
        eyesImg_3.setAttribute('data-ok',true);
        noseImg_3.setAttribute('data-ok',true);
        mouseImg_3.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_2");
        nose_container.classList.add("hover_2");
        mouse_container.classList.add("hover_2");
    });
    choice[3].addEventListener("click",()=>{//슬픔
        eyes_img.src = "image/눈3.png";
        nose_img.src = "image/코3.png";
        mouse_img.src = "image/입3.png";
        ex_img.src = "image/boy/완성이미지_4.png";
        document.body.style.backgroundImage ="url(image/배경1.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
        
        eyesImg_1.setAttribute('data-ok',true);
        noseImg_1.setAttribute('data-ok',true);
        mouseImg_1.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_3");
        nose_container.classList.add("hover_3");
        mouse_container.classList.add("hover_3");
    });
}


/* 여자 얼굴  */
function girl(){
    
choice[4].addEventListener("click",()=>{//사랑
    face_container.classList.add("hover");
    face_img.src = "image/작업이미지_2.png";
    body_img.src = "image/상반신_2.png";
    eyes_img.src = "image/눈0.png";
    nose_img.src = "image/코0.png";
    mouse_img.src = "image/입0.png";
    ex_img.src = "image/girl/완성이미지_1.png";
    document.body.style.backgroundImage ="url(image/배경2.png)";
    
});
choice[5].addEventListener("click",()=>{//졸음
    face_container.classList.add("hover");
    face_img.src = "image/작업이미지_2.png";
    body_img.src = "image/상반신_2.png";
    eyes_img.src = "image/눈1.png";
    nose_img.src = "image/코1.png";
    mouse_img.src = "image/입1.png";
    ex_img.src = "image/girl/완성이미지_2.png";
    document.body.style.backgroundImage ="url(image/배경2.png)";

    eyesImg_2.removeAttribute('data-ok',false);
    noseImg_2.removeAttribute('data-ok',false);
    mouseImg_2.removeAttribute('data-ok',false);

    eyesImg_4.setAttribute('data-ok',true);
    noseImg_4.setAttribute('data-ok',true);
    mouseImg_4.setAttribute('data-ok',true);
    eyes_container.classList.add("hover_1");
    nose_container.classList.add("hover_1");
    mouse_container.classList.add("hover_1");
});
choice[6].addEventListener("click",()=>{//웃음
    face_container.classList.add("hover");
    face_img.src = "image/작업이미지_2.png";
    body_img.src = "image/상반신_2.png";
    eyes_img.src = "image/눈2.png";
    nose_img.src = "image/코2.png";
    mouse_img.src = "image/입2.png";
    document.body.style.backgroundImage ="url(image/배경2.png)";

    eyesImg_2.removeAttribute('data-ok',false);
    noseImg_2.removeAttribute('data-ok',false);
    mouseImg_2.removeAttribute('data-ok',false);

    eyesImg_3.setAttribute('data-ok',true);
    // eyesImg_4.src = 'image/눈4.png';
    noseImg_3.setAttribute('data-ok',true);
    // noseImg_4.src = 'image/코4.png';
    mouseImg_3.setAttribute('data-ok',true);
    eyes_container.classList.add("hover_4");
    nose_container.classList.add("hover_4");
    mouse_container.classList.add("hover_4");
    ex_img.src = "image/girl/완성이미지_3.png";
});
choice[7].addEventListener("click",()=>{//슬픔
    face_container.classList.add("hover");
    face_img.src = "image/작업이미지_2.png";
    body_img.src = "image/상반신_2.png";
    eyes_img.src = "image/눈3.png";
    nose_img.src = "image/코3.png";
    mouse_img.src = "image/입3.png";
    ex_img.src = "image/girl/완성이미지_4.png";
    document.body.style.backgroundImage ="url(image/배경2.png)";

    eyesImg_2.removeAttribute('data-ok',false);
    noseImg_2.removeAttribute('data-ok',false);
    mouseImg_2.removeAttribute('data-ok',false);
    
    eyesImg_1.setAttribute('data-ok',true);
    noseImg_1.setAttribute('data-ok',true);
    mouseImg_1.setAttribute('data-ok',true);
    eyes_container.classList.add("hover_3");
    nose_container.classList.add("hover_3");
    mouse_container.classList.add("hover_3");
});
}



/* 할아버지 얼굴 */
function grandfather(){//사랑
    choice[8].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandfather/얼굴.png";
        body_img.src = "image/grandfather/몸통.png";
        eyes_img.src = "image/눈0.png";
        nose_img.src = "image/grandfather/코0.png";
        mouse_img.src = "image/입0.png";
        ex_img.src = "image/grandfather/완성이미지_1.png";
        document.body.style.backgroundImage ="url(image/배경3.png)";


    
    });
    choice[9].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandfather/얼굴.png";
        body_img.src = "image/grandfather/몸통.png";
        eyes_img.src = "image/눈1.png";
        nose_img.src = "image/grandfather/코1.png";
        mouse_img.src = "image/입1.png";
        ex_img.src = "image/grandfather/완성이미지_2.png";
        document.body.style.backgroundImage ="url(image/배경3.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
    
        eyesImg_4.setAttribute('data-ok',true);
        noseImg_4.setAttribute('data-ok',true);
        mouseImg_4.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_1");
        nose_container.classList.add("hover_1");
        mouse_container.classList.add("hover_1");
    });
    choice[10].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandfather/얼굴.png";
        body_img.src = "image/grandfather/몸통.png";
        eyes_img.src = "image/눈2.png";
        nose_img.src = "image/grandfather/코2.png";
        mouse_img.src = "image/입2.png";
        ex_img.src = "image/grandfather/완성이미지_3.png";
        document.body.style.backgroundImage ="url(image/배경3.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
    
        eyesImg_3.setAttribute('data-ok',true);
        // eyesImg_4.src = 'image/눈4.png';
        noseImg_3.setAttribute('data-ok',true);
        // noseImg_4.src = 'image/코4.png';
        mouseImg_3.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_4");
        nose_container.classList.add("hover_4");
        mouse_container.classList.add("hover_4");
    
    });
    choice[11].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandfather/얼굴.png";
        body_img.src = "image/grandfather/몸통.png";
        eyes_img.src = "image/눈3.png";
        nose_img.src = "image/grandfather/코3.png";
        mouse_img.src = "image/입3.png";
        ex_img.src = "image/grandfather/완성이미지_4.png";
        document.body.style.backgroundImage ="url(image/배경3.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
        
        eyesImg_1.setAttribute('data-ok',true);
        noseImg_1.setAttribute('data-ok',true);
        mouseImg_1.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_3");
        nose_container.classList.add("hover_3");
        mouse_container.classList.add("hover_3");
    });
}


function grandmother(){
//1. choice[12~15]
/* 할머니 얼굴 */
    choice[12].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandmother/얼굴.png";
        body_img.src = "image/grandmother/몸통.png";
        eyes_img.src = "image/눈0.png";
        nose_img.src = "image/grandmother/코0.png";
        mouse_img.src = "image/입0.png";
        ex_img.src = "image/grandmother/완성이미지_1.png";
        document.body.style.backgroundImage ="url(image/배경4.png)";


    });
    choice[13].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandmother/얼굴.png";
        body_img.src = "image/grandmother/몸통.png";
        eyes_img.src = "image/눈1.png";
        nose_img.src = "image/grandmother/코1.png";
        mouse_img.src = "image/입1.png";
        ex_img.src = "image/grandmother/완성이미지_2.png";
        document.body.style.backgroundImage ="url(image/배경4.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);

        eyesImg_4.setAttribute('data-ok',true);
        noseImg_4.setAttribute('data-ok',true);
        mouseImg_4.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_1");
        nose_container.classList.add("hover_1");
        mouse_container.classList.add("hover_1");
    });
    choice[14].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandmother/얼굴.png";
        body_img.src = "image/grandmother/몸통.png";
        eyes_img.src = "image/눈2.png";
        nose_img.src = "image/grandmother/코2.png";
        mouse_img.src = "image/입2.png";
        ex_img.src = "image/grandmother/완성이미지_3.png";
        document.body.style.backgroundImage ="url(image/배경4.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);

        eyesImg_3.setAttribute('data-ok',true);
        // eyesImg_4.src = 'image/눈4.png';
        noseImg_3.setAttribute('data-ok',true);
        // noseImg_4.src = 'image/코4.png';
        mouseImg_3.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_4");
        nose_container.classList.add("hover_4");
        mouse_container.classList.add("hover_4");

    });
    choice[15].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/grandmother/얼굴.png";
        body_img.src = "image/grandmother/몸통.png";
        eyes_img.src = "image/눈3.png";
        nose_img.src = "image/grandmother/코3.png";
        mouse_img.src = "image/입3.png";
        ex_img.src = "image/grandmother/완성이미지_4.png";
        document.body.style.backgroundImage ="url(image/배경4.png)";


        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
        
        eyesImg_1.setAttribute('data-ok',true);
        noseImg_1.setAttribute('data-ok',true);
        mouseImg_1.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_3");
        nose_container.classList.add("hover_3");
        mouse_container.classList.add("hover_3");
    });
}

function baby(){
//1. choice[16~19]
/* 애기얼굴 */
    choice[16].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/baby/얼굴.png";
        body_img.src = "image/baby/몸통.png";
        eyes_img.src = "image/눈0.png";
        nose_img.src = "image/baby/코0.png";
        mouse_img.src = "image/입0.png";
        ex_img.src = "image/baby/완성이미지_1.png";
        noseImg_2.src = "image/baby/코0.png";
        document.body.style.backgroundImage ="url(image/배경5.png)";


    });
    choice[17].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/baby/얼굴.png";
        body_img.src = "image/baby/몸통.png";
        eyes_img.src = "image/눈1.png";
        nose_img.src = "image/baby/코1.png";
        mouse_img.src = "image/입1.png";
        ex_img.src = "image/baby/완성이미지_2.png";
        noseImg_2.src = "image/baby/코0.png";
        document.body.style.backgroundImage ="url(image/배경5.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);

        eyesImg_4.setAttribute('data-ok',true);
        noseImg_4.setAttribute('data-ok',true);
        mouseImg_4.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_1");
        nose_container.classList.add("hover_1");
        mouse_container.classList.add("hover_1");
    });
    choice[18].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/baby/얼굴.png";
        body_img.src = "image/baby/몸통.png";
        eyes_img.src = "image/눈2.png";
        nose_img.src = "image/baby/코2.png";
        mouse_img.src = "image/입2.png";
        ex_img.src = "image/baby/완성이미지_3.png";
        noseImg_2.src = "image/baby/코0.png";
        document.body.style.backgroundImage ="url(image/배경5.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);

        eyesImg_3.setAttribute('data-ok',true);
        // eyesImg_4.src = 'image/눈4.png';
        noseImg_3.setAttribute('data-ok',true);
        // noseImg_4.src = 'image/코4.png';
        mouseImg_3.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_4");
        nose_container.classList.add("hover_4");
        mouse_container.classList.add("hover_4");

    });
    choice[19].addEventListener("click",()=>{
        face_container.classList.add("hover");
        face_container.style.height = "65%";
        face_img.src = "image/baby/얼굴.png";
        body_img.src = "image/baby/몸통.png";
        eyes_img.src = "image/눈3.png";
        nose_img.src = "image/baby/코3.png";
        mouse_img.src = "image/입3.png";
        ex_img.src = "image/baby/완성이미지_4.png";
        noseImg_2.src = "image/baby/코0.png";
        document.body.style.backgroundImage ="url(image/배경5.png)";

        eyesImg_2.removeAttribute('data-ok',false);
        noseImg_2.removeAttribute('data-ok',false);
        mouseImg_2.removeAttribute('data-ok',false);
        
        eyesImg_1.setAttribute('data-ok',true);
        noseImg_1.setAttribute('data-ok',true);
        mouseImg_1.setAttribute('data-ok',true);
        eyes_container.classList.add("hover_3");
        nose_container.classList.add("hover_3");
        mouse_container.classList.add("hover_3");
    });
}
boy();
girl();
grandfather();
grandmother();
baby();
var moveImg = null, startX, startY;
function eyes(){
    document.querySelectorAll('.list_1 img').forEach((img) => {

        img.addEventListener('touchstart', (e) => {
            console.log("h2");
            //드랙 대상의 위치와 초기 좌표 계산
            var bound = e.target.getBoundingClientRect();//img의 getBoundingClientRect();
            startX = e.touches[0].pageX;// 터치 X,Y
            startY = e.touches[0].pageY;
    
            //드랙 대상의 복사본을 만들어서 body 에 추가
            moveImg = e.target.cloneNode();
            moveImg.style.position = 'fixed';
            moveImg.style.left = bound.x + 'px';
            moveImg.style.top = bound.y + 'px'; //복사된 moveImg의 좌표
            moveImg.style.width = bound.width + 'px'; //너비
            moveImg.style.height = bound.height + 'px'; //높이
            document.body.appendChild(moveImg); //body안에 clone을 추가.
            moveImg.style.zIndex = "2";
            //드랙 원본 감추기 또는 반투명
            //e.target.style.visibility = 'hidden';
            e.target.style.opacity = .5; //누름과 동시에 clone 이외의 이미지는 opacity
        });
    
        img.addEventListener("touchmove", (e) => {
            if(moveImg != null){
                var movedX = e.touches[0].pageX - startX;
                var movedY = e.touches[0].pageY - startY;
                moveImg.style.transform = `translate(${movedX}px, ${movedY}px)`;
            }
        });
    
        img.addEventListener('touchend', (e) => {
            if (moveImg != null) {
                var eye = document.querySelector('.eyes_img');
                var eyeBox = eye.getBoundingClientRect();
                var bound = moveImg.getBoundingClientRect();
                let O = document.querySelector(".O");
                let X = document.querySelector(".X");
                //드롭이 맞게 되었다면 드랙 사본을 드롭 영역에 추가
                if (
                    moveImg.matches('[data-ok]') &&
                    bound.right >= eyeBox.left && bound.left <= eyeBox.right &&
                    bound.bottom >= eyeBox.top && bound.top <= eyeBox.bottom
                ) {
                    setTimeout(() => {
                        O.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        O.style.visibility = "visible";
                        O.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        O.style.opacity = "0";
                        O.style.zIndex = "0";
                        O.style.visibility = "hidden";
                    }, 1000);
                    eye.appendChild(moveImg);
                    moveImg.style.position = 'static';
                    moveImg.style.transform = 'none';
                    eye.style.opacity = "1";
                    //드랙 원본을 터치 불가로 만들기
                    e.target.style.pointerEvents = 'none';
                    list_main_container.classList.remove("hover");
                }
                //드롭이 틀리게 되었다면 드랙 사본을 원래위치로 보낸 후 body 에서 삭제
                else {
                    setTimeout(() => {
                        X.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        X.style.visibility = "visible";
                        X.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        X.style.opacity = "0";
                        X.style.zIndex = "-1";
                        O.style.visibility = "hidden";
                    }, 1000);
                    moveImg.style.transition = 'transform .3s linear';
                    moveImg.style.transform = 'none';
                    moveImg.addEventListener('transitionend', (e) => {
                        document.body.removeChild(e.target);
                        // X.style.zIndex = "-1";

                    });
                    //드랙 원본 다시 보여주기
                    //e.target.style.visibility = 'visibile';
                    e.target.style.opacity = 1;
                }
            }
            //드랙 변수 null 처리
            moveImg = null;
        });
    });
}
function nose(){
    document.querySelectorAll('.list_2 img').forEach((img) => {
        img.addEventListener('touchstart', (e) => {
    
            //드랙 대상의 위치와 초기 좌표 계산
            var bound = e.target.getBoundingClientRect();//img의 getBoundingClientRect();
            startX = e.touches[0].pageX;// 터치 X,Y
            startY = e.touches[0].pageY;
    
            //드랙 대상의 복사본을 만들어서 body 에 추가
            moveImg = e.target.cloneNode();
            moveImg.style.position = 'fixed';
            moveImg.style.left = bound.x + 'px';
            moveImg.style.top = bound.y + 'px';//복사된 moveImg의 좌표
            moveImg.style.width = bound.width + 'px'; //너비
            moveImg.style.height = bound.height + 'px'; //높이
            document.body.appendChild(moveImg); //body안에 clone을 추가.
            moveImg.style.zIndex = "2";
            //드랙 원본 감추기 또는 반투명
            //e.target.style.visibility = 'hidden';
            e.target.style.opacity = .5; //누름과 동시에 clone 이외의 이미지는 opacity
        });
    
        img.addEventListener("touchmove", (e) => {
            if(moveImg != null){
                var movedX = e.touches[0].pageX - startX;
                var movedY = e.touches[0].pageY - startY;
                moveImg.style.transform = `translate(${movedX}px, ${movedY}px)`;
            }
        });
    
        img.addEventListener('touchend', (e) => {
            if (moveImg != null) {
                var eye = document.querySelector('.nose_img');
                var eyeBox = eye.getBoundingClientRect();
                var bound = moveImg.getBoundingClientRect();
                let O = document.querySelector(".O");
                let X = document.querySelector(".X");
                //드롭이 맞을 시
                if (
                    moveImg.matches('[data-ok]') &&
                    bound.right >= eyeBox.left && bound.left <= eyeBox.right &&
                    bound.bottom >= eyeBox.top && bound.top <= eyeBox.bottom
                ) {
                    setTimeout(() => {
                        O.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        O.style.visibility = "visible";
                        O.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        O.style.opacity = "0";
                        O.style.zIndex = "0";
                        O.style.visibility = "hidden";
                    }, 1000);
                    eye.appendChild(moveImg);
                    moveImg.style.position = 'static';
                    moveImg.style.transform = 'none';
                    eye.style.opacity = "1";
                    //드랙 원본을 터치 불가로 만들기
                    e.target.style.pointerEvents = 'none';
                    list_main_container.classList.remove("hover");
                }
                //드롭이 틀릴 시
                else {
                    setTimeout(() => {
                        X.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        X.style.visibility = "visible";
                        X.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        X.style.opacity = "0";
                        X.style.zIndex = "-1";
                        O.style.visibility = "hidden";
                    }, 1000);
                    moveImg.style.transition = 'transform .3s linear';
                    moveImg.style.transform = 'none';
                    moveImg.addEventListener('transitionend', (e) => {
                        document.body.removeChild(e.target);
                    });
    
                    //드랙 원본 다시 보여주기
                    //e.target.style.visibility = 'visibile';
                    e.target.style.opacity = 1;
                }
            }
            //드랙 변수 null 처리
            moveImg = null;
        });
    });
}
function mouse(){
    document.querySelectorAll('.list_3 img').forEach((img) => {
        img.addEventListener('touchstart', (e) => {
    
            //드랙 대상의 위치와 초기 좌표 계산
            var bound = e.target.getBoundingClientRect();//img의 getBoundingClientRect();
            startX = e.touches[0].pageX;// 터치 X,Y
            startY = e.touches[0].pageY;
    
            //드랙 대상의 복사본을 만들어서 body 에 추가
            moveImg = e.target.cloneNode();
            moveImg.style.position = 'fixed';
            moveImg.style.left = bound.x + 'px';
            moveImg.style.top = bound.y + 'px';//복사된 moveImg의 좌표
            moveImg.style.width = bound.width + 'px'; //너비
            moveImg.style.height = bound.height + 'px'; //높이
            document.body.appendChild(moveImg); //body안에 clone을 추가.
            moveImg.style.zIndex = "2";
            //드랙 원본 감추기 또는 반투명
            //e.target.style.visibility = 'hidden';
            e.target.style.opacity = .5; //누름과 동시에 clone 이외의 이미지는 opacity
        });
    
        img.addEventListener("touchmove", (e) => {
            if(moveImg != null){
                var movedX = e.touches[0].pageX - startX;
                var movedY = e.touches[0].pageY - startY;
                moveImg.style.transform = `translate(${movedX}px, ${movedY}px)`;
                moveImg.style.zIndex = "10";
                
            }
        });
    
        img.addEventListener('touchend', (e) => {
            if (moveImg != null) {
                var eye = document.querySelector('.mouse_img');
                var eyeBox = eye.getBoundingClientRect();
                var bound = moveImg.getBoundingClientRect();
                let O = document.querySelector(".O");
                let X = document.querySelector(".X");
                //드롭이 맞게 되었다면 드랙 사본을 드롭 영역에 추가
                if (
                    moveImg.matches('[data-ok]') &&
                    bound.right >= eyeBox.left && bound.left <= eyeBox.right &&
                    bound.bottom >= eyeBox.top && bound.top <= eyeBox.bottom
                ) {
                    setTimeout(() => {
                        O.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        O.style.visibility = "visible";
                        O.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        O.style.opacity = "0";
                        O.style.zIndex = "0";
                        O.style.visibility = "hidden";
                    }, 1000);
                    eye.appendChild(moveImg);
                    moveImg.style.position = 'static';
                    moveImg.style.transform = 'none';
                    eye.style.opacity = "1";
                    //드랙 원본을 터치 불가로 만들기
                    e.target.style.pointerEvents = 'none';
                    list_main_container.classList.remove("hover");
                }
                //드롭이 틀리게 되었다면 드랙 사본을 원래위치로 보낸 후 body 에서 삭제
                else {
                    setTimeout(() => {
                        X.style.zIndex = "1";
                    }, 100);
                    setTimeout(() => {
                        X.style.visibility = "visible";
                        X.style.opacity = "1";
                    }, 300);
                    setTimeout(() => {
                        X.style.opacity = "0";
                        X.style.zIndex = "-1";
                        O.style.visibility = "hidden";
                    }, 1000);
                    moveImg.style.transition = 'transform .3s linear';
                    moveImg.style.transform = 'none';
                    moveImg.addEventListener('transitionend', (e) => {
                        document.body.removeChild(e.target);
                    });
    
                    //드랙 원본 다시 보여주기
                    //e.target.style.visibility = 'visibile';
                    e.target.style.opacity = 1;
                }
            }
            //드랙 변수 null 처리
            moveImg = null;
        });
    });
}
nose();
eyes();
mouse();

/* 눈, 코, 입 툴바 선택시 정리 */
var list_1, list_2, list_3;
list_1 = document.querySelector(".list_1");
list_2 = document.querySelector(".list_2");
list_3 = document.querySelector(".list_3");
let body = document.querySelector("body");
var list_main_container = document.querySelector(".list_main_container");
var btn1, btn2, btn3;
btn1 = document.querySelector(".btn1");
btn2 = document.querySelector(".btn2");
btn3 = document.querySelector(".btn3");
btn1.addEventListener("click",()=>{
    list_main_container.classList.add("hover");
    list_1.style.zIndex = "1";
    list_2.style.zIndex = "0";
    list_3.style.zIndex = "0";
    btn1.style.zIndex = "1";
    btn2.style.zIndex = "0";
    btn3.style.zIndex = "0";

});
btn2.addEventListener("click",()=>{
    list_main_container.classList.add("hover");
    list_1.style.zIndex = "0";
    list_2.style.zIndex = "1";
    list_3.style.zIndex = "-1";
    btn1.style.zIndex = "0";
    btn2.style.zIndex = "1";
    btn3.style.zIndex = "0";
});
btn3.addEventListener("click",()=>{
    list_main_container.classList.add("hover");
    list_1.style.zIndex = "-1";
    list_2.style.zIndex = "0";
    list_3.style.zIndex = "1";
    btn1.style.zIndex = "0";
    btn2.style.zIndex = "0";
    btn3.style.zIndex = "1";
});
