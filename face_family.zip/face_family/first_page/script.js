let page1_container = document.querySelector(".page1_container");
let choice = document.querySelectorAll(".choice");
let vision = document.querySelector(".vision");
for(let i = 0; i < 3; i++){
    choice[i].addEventListener("click", ()=>{
            vision.classList.add("hover");
    });
}
